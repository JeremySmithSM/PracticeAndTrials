﻿using System;

namespace RJSLabCsCh13AbstractShapes
{
	class Program
	{
		static void Main(string[] args)
		{

			Shape s = new Square(2);
			Console.WriteLine(s.GetArea());
			Console.WriteLine(s.GetPerimeter());


			Shape Cercie = new Circle("Green", radius: 4);
			Shape Squirrel = new Square("Yellow", side: 8);
			Shape Rekt = new Rectangle("Red", length: 5, width: 6);
			Shape ThighAngel = new Triangle("Black", sideA: 3, sideB: 4, sideC: 5);

			Console.WriteLine("Circle Cercie Color= {0}, Radius= {1}",
				Cercie.GetColor(), ((Circle)Cercie).GetRadius());
			Console.WriteLine("Circle Cercie Circumference= {0}, Area= {1}",
				Cercie.GetPerimeter(), Cercie.GetArea());

			Console.WriteLine("Square Squirrel Color= {0}, Side= {1}",
				Squirrel.GetColor(), ((Square)Squirrel).GetSide());
			Console.WriteLine("Square Squirrel Perimeter= {0}, Area= {1}",
				Squirrel.GetPerimeter(), Squirrel.GetArea());

			Console.WriteLine("Rectangle Rekt Color= {0}, Length= {1}, Width= {2}",
				Rekt.GetColor(), ((Rectangle)Rekt).GetLength(), ((Rectangle)Rekt).GetWidth());
			Console.WriteLine("Rectangle Rekt Perimeter= {0}, Area {1}",
				Rekt.GetPerimeter(), Rekt.GetArea());

			Console.WriteLine("Triangle ThighAngel Color= {0}, Sides= {1}",
				ThighAngel.GetColor(), ((Triangle)ThighAngel).GetSides());
			Console.WriteLine("Triangle ThighAngel Perimeter= {0}, Area= {1}",
				ThighAngel.GetPerimeter(), ThighAngel.GetArea());


		}
	}
}
