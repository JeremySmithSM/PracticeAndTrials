﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RJSLabCsCh13AbstractShapes
{
	public class Triangle : Shape
	{
		// F I E L D S
		private double sideA = 1;
		private double sideB = 1;
		private double sideC = 1;

		// C O N S T R U C T O R S
		public Triangle(double sideA = 1, double sideB = 1, double sideC = 1, string color = "White")
			: base(color)
		{
			SetSides(sideA, sideB, sideC);
		}
		public Triangle(string color = "White", double sideA = 1, double sideB = 1, double sideC = 1)
			: base(color)
		{
			//SetColor(color);
			SetSides(sideA, sideB, sideC);
		}

		// M E T H O D S
		public (double, double, double) GetSides() => (sideA, sideB, sideC);

		public void SetSides(double sideA, double sideB, double sideC)
		{
			if ((sideA > 0) && (sideB > 0) && (sideC > 0) && (sideA + sideB > sideC) 
				&& (sideA + sideC > sideB) && (sideC + sideB > sideA))
			{
				this.sideA = sideA;
				this.sideB = sideB;
				this.sideC = sideC;
			}
		}

		public override double GetPerimeter() => sideA + sideB + sideC;

		public override double GetArea() => 0.25 * Math.Sqrt(
			(sideA + sideB + sideC) * (sideB + sideC - sideA) *
			(sideA - sideB + sideC) * (sideA + sideB - sideC));

	}
}
