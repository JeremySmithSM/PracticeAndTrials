﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RJSLabCsCh13AbstractShapes
{
	public class Circle : Shape
	{
		// Fields
		private double radius = 1;

		// Constructor
		public Circle(double radius = 1, string color = "White")
			: base(color)
		{
			SetRadius(radius);
		}
		public Circle(string color = "White", double radius = 1)
			: base(color)
		{
			//SetColor(color);
			SetRadius(radius);
		}

		// Methods
		public double GetRadius() => radius;

		public void SetRadius(double radius)
		{
			if (radius > 0)
			{
				this.radius = radius;
			}
		}

		public override double GetPerimeter() => 2.0 * Math.PI * radius;

		public override double GetArea() => Math.PI * radius * radius;

	}
}
