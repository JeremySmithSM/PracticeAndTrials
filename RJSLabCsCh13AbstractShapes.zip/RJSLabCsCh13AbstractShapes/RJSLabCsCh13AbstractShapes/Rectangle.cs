﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RJSLabCsCh13AbstractShapes
{
	public class Rectangle : Shape
	{
		//		F I E L D S   &   P R O P E R T I E S
		private double length = 1;
		private double width = 1;

		//		C O N S T R U C T O R S
		public Rectangle(double length = 1, double width = 1, string color = "White")
			: base(color)
		{
			SetLength(length);
			SetWidth(width);
		}
		public Rectangle(string color = "White", double length = 1, double width = 1)
			: base(color)
		{
			//SetColor(color);
			SetLength(length);
			SetWidth(width);
		}

		//		M E T H O D S
		public double GetLength() => length;
		public double GetWidth() => width;

		public void SetLength(double newlength)
		{
			if (newlength > 0)
			{
				length = newlength;
			}
		}
		public void SetWidth(double newwidth)
		{
			if (newwidth > 0)
			{
				length = newwidth;
			}
		}

		public override double GetPerimeter() => length * 2 + width * 2;

		public override double GetArea() => length * width;





	}
}
