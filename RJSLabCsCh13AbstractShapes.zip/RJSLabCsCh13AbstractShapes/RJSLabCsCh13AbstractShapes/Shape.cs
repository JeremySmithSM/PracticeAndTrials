﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RJSLabCsCh13AbstractShapes
{
	abstract public class Shape
	{
		// FIELDS
		private string color = "White";

		// CONSTRUCTORS
		protected Shape()
		{ }
		protected Shape(string color = "White")
		{
			SetColor(color);
		}


		// METHODS
		public string GetColor() => color;

		public void SetColor(string color)
		{
			this.color = color;
		}

		abstract public double GetPerimeter();

		abstract public double GetArea();

	}
}
