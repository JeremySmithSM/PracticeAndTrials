﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RJSLabCsCh13AbstractShapes
{
	public class Square : Shape
	{
		// F I E L D S
		private double side = 1;

		// C O N S T R U C T O R S
		public Square(double side = 1, string color = "White")
			: base(color)
		{
			SetSide(side);
		}

		public Square(string color = "White", double side = 1)
			: base(color)
		{
			//SetColor(color);
			SetSide(side);
		}

		// M E T H O D S
		public double GetSide() => this.side;

		public void SetSide(double side)
		{
			if (side > 0)
			{
				this.side = side;
			}
		}

		public override double GetPerimeter() => side * 4;

		public override double GetArea() => side * side;

	}
}
