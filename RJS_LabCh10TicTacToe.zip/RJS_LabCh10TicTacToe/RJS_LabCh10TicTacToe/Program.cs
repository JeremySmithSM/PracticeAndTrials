﻿using System;

namespace RJS_LabCh10TicTacToe
{
	class Program
	{
		static void Main(string[] args)
		{
			char[,] board = //new char[3, 3] 
			{ { '-', '-', '-' }, { '-', '-', '-' }, { '-', '-', '-' } };


			// ENDING CONDITIONS: all 9 spots are taken,
			//			3 in a row, col, diagonal
			//			!!RAGEQUIT!!
			//TO DO: separate player moves to check for max board size

			bool win = false;
			for (int movesMade = 0; movesMade <= 9 && win == false; )
			{
				if (win == false && movesMade < 9)
				{
					PlayerMove(board, 1, 'x');
					movesMade++;
					print2DArray(board);
					win = WINNER(board, 1, 'x');
				}
				if (win == false && movesMade < 9)
				{
					PlayerMove(board, 2, 'o');
					movesMade++;
					print2DArray(board);
					win = WINNER(board, 2, 'o');
				}
				if (win == false && movesMade == 9)
				{
					Console.WriteLine("It's a tie, you are both losers, go home!");
				}
				if (win == true)
				{
					break;
				}
			}
			Console.WriteLine("END OF LINE.");

		}


		public static bool WINNER(char[,] array, int player, char xo)
		{
			for (int r = 0; r <= array.GetUpperBound(0); r++) //3 in a column win
			{
				if (array[r, 0] == xo && array[r, 1] == xo && array[r, 2] == xo)
				{
					Console.WriteLine("Player " + player + " wins!");
					return true;
				}
			}
			for (int c = 0; c <= array.GetUpperBound(1); c++) //3 in a row win
			{
				if (array[0, c] == xo && array[1, c] == xo && array[2, c] == xo)
				{
					Console.WriteLine("Player " + player + " wins!");
					return true;
				}
			}
			if (array[0, 0] == xo && array[1, 1] == xo && array[2, 2] == xo) //3 in a diag win
			{
				Console.WriteLine("Player " + player + " wins!");
				return true;
			}
			if (array[2, 0] == xo && array[1, 1] == xo && array[0, 2] == xo) //3 in a diag win
			{
				Console.WriteLine("Player " + player + " wins!");
				return true;
			}
			return false;
		}


		public static void print2DArray(char[,] input)
		{
			Console.WriteLine(
				input[0, 0] + " " + input[0, 1] + " " + input[0, 2]);
			Console.WriteLine(
				input[1, 0] + " " + input[1, 1] + " " + input[1, 2]);
			Console.WriteLine(
				input[2, 0] + " " + input[2, 1] + " " + input[2, 2]);
		}


		public static void PlayerMove(char[,] array, int player, char c)
		{
			bool keepgoin = true;
			while (keepgoin == true)
			{
				Console.WriteLine("PLAYER " + player + " Move.");
				int rowInd = 0;
				int colInd = 0;
				do
				{
					Console.Write("Choose Row: ");
					rowInd = int.Parse(Console.ReadLine()) - 1;
				} while (rowInd > 2 || rowInd < 0);

				do
				{
					Console.Write("Choose Column: ");
					colInd = int.Parse(Console.ReadLine()) - 1;
				} while (colInd > 2 || colInd < 0);

				if (array[rowInd, colInd] == '-')
				{
					array[rowInd, colInd] = c;
					keepgoin = false;
				}
				else
				{
					Console.WriteLine("That spot is taken! choose another!");
				}
			}
		}
	}
}
